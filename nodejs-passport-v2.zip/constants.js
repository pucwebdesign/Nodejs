export const urls = {
    application: "http://localhost:3000"
}